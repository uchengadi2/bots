# ext-theme-neptune-a84f4ef6-d03d-4fe5-94f5-cd44da8e564d/resources

This folder contains static resources (typically an `"images"` folder as well).
