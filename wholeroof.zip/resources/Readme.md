# ext-theme-neptune-be86ff41-32f9-40c2-9721-a48e882a1a29/resources

This folder contains static resources (typically an `"images"` folder as well).
