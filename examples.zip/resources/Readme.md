# ext-theme-neptune-e0f3f485-6317-45dc-bae1-cfaf06c84f2e/resources

This folder contains static resources (typically an `"images"` folder as well).
